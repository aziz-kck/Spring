# SpringBootRepo
Repository for academic purpose 👩‍🎓💻
Basics of SpringBoot framework.
