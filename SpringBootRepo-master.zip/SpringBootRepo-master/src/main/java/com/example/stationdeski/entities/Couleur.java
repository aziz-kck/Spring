package com.example.stationdeski.entities;

public enum Couleur {
    BLEU,ROUGE,VERT,NOIR;
}
