package com.example.stationdeski.entities;

public enum Support {
    SKI,SNOWBOARD;
}
