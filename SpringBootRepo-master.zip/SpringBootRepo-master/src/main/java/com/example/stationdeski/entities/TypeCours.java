package com.example.stationdeski.entities;

public enum TypeCours {
    COLLECTIF_ENFANT,COLLECTIF_ADULTE,PARTICULIER;
}
