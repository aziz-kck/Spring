package com.example.stationdeski.entities;

public enum typeAbonnement {
    ANNUEL,SEMESTRIEL,MENSUEL;
}
